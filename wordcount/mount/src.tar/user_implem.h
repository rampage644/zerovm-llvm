/*
 * user_implem.h
 *
 *  Created on: 15.07.2012
 *      Author: yaroslav
 */

#ifndef USER_IMPLEM_H_
#define USER_IMPLEM_H_

struct MapReduceUserIf;

void InitInterface( struct MapReduceUserIf* mr_if );

#endif /* USER_IMPLEM_H_ */
